#!/usr/bin/env bash
set -e

echo "=== DIANA Startup Script ==="

# Check if ollama is available
if ! command -v ollama &>/dev/null; then
  echo "ERROR: Ollama not found. Install it first."
  exit 1
fi

# Start Ollama server in background if not already running
if ! curl -sf http://localhost:11434/api/tags >/dev/null 2>&1; then
  echo "Starting Ollama server..."
  OLLAMA_HOST=127.0.0.1 ollama serve &
  OLLAMA_PID=$!
  echo "Ollama PID: $OLLAMA_PID"
  
  # Wait for Ollama to be ready
  echo "Waiting for Ollama to be ready..."
  for i in $(seq 1 30); do
    if curl -sf http://localhost:11434/api/tags >/dev/null 2>&1; then
      echo "Ollama is ready!"
      break
    fi
    sleep 2
    echo "  Still waiting... ($i/30)"
  done
else
  echo "Ollama is already running."
fi

# Pull the model if not already available
MODEL="${OLLAMA_MODEL:-llama3.2}"
echo "Checking model: $MODEL..."
if ! ollama list 2>/dev/null | grep -q "$MODEL"; then
  echo "Downloading model $MODEL... This may take a few minutes."
  ollama pull "$MODEL"
  echo "Model $MODEL downloaded successfully!"
else
  echo "Model $MODEL is already available."
fi

echo "=== DIANA backend ready! ==="
