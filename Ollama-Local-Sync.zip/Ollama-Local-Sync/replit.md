# DIANA - IA de Voz

## Overview

DIANA (Digital Intelligence And Neural Assistant) — a fully local AI voice chat assistant. No external APIs — all AI processing, speech recognition, and text-to-speech run locally.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **AI Engine**: Ollama (llama3.2 model)
- **Speech-to-Text**: Web Speech API (SpeechRecognition, browser-native)
- **Text-to-Speech**: Web Speech API (SpeechSynthesis, browser-native, pt-BR voice)
- **Frontend**: React + Vite (artifacts/diana)
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Architecture

```
artifacts/
├── diana/           # React frontend (UI, voice, chat)
├── api-server/      # Express backend (Ollama integration, session management)
lib/
├── api-spec/        # OpenAPI contract
├── api-client-react/# Generated React Query hooks
scripts/
└── start-diana.sh   # Ollama startup helper script
```

## Key Features

1. **Chat with DIANA**: Text-based conversation with full context memory per session
2. **Voice Call Mode**: Start a continuous voice call — microphone → STT → Ollama → TTS → repeat
3. **4 Personalities**: Amiga Empática, Professora Paciente, Coach Motivacional, Assistente Profissional
4. **Status monitoring**: Real-time check if Ollama/model is running
5. **Session management**: Per-session conversation history with reset capability

## API Endpoints

- `POST /api/diana/chat` — Send message, get AI response
- `POST /api/diana/personality` — Switch personality
- `GET /api/diana/status` — Check Ollama + model status
- `POST /api/diana/reset` — Clear conversation history
- `GET /api/diana/voices` — Voice configuration info

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/diana run dev` — run frontend locally

## Ollama Setup

Ollama is installed via Nix. On first run:
1. `ollama serve` — start Ollama server
2. `ollama pull llama3.2` — download the model (~2GB)

Or use `scripts/start-diana.sh` for automated setup.

## Environment Variables

- `OLLAMA_HOST` — Ollama server URL (default: http://127.0.0.1:11434)
- `OLLAMA_MODEL` — Model to use (default: llama3.2)
- `PORT` — Server port (set by Replit)

## Notes

- The model download (llama3.2) takes a few minutes on first run
- The frontend shows "DIANA offline" when Ollama is not ready
- All processing is 100% local — no external API calls for AI or voice
- Voice uses browser Web Speech API — no server-side audio processing
