{pkgs}: {
  deps = [
    pkgs.ollama
  ];
}
