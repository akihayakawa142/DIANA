import { useState } from "react";
import { Send, Phone, Menu, Trash2, Zap, Brain } from "lucide-react";
import { useDianaChat, type Mode } from "@/hooks/use-diana-chat";
import { ChatArea } from "@/components/chat-area";
import { PersonalitySelector } from "@/components/personality-selector";
import { VoiceCallOverlay } from "@/components/voice-call-overlay";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

function ModeToggle({ currentMode, onChange, disabled }: { currentMode: Mode; onChange: (m: Mode) => void; disabled?: boolean }) {
  return (
    <div className="p-4 border-b border-white/5">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">Modo de Resposta</p>
      <div className="flex rounded-xl overflow-hidden border border-white/10 bg-background/40">
        <button
          onClick={() => onChange("fast")}
          disabled={disabled}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold transition-all duration-200 disabled:opacity-40 ${
            currentMode === "fast"
              ? "bg-gradient-to-r from-cyan-500/20 to-primary/20 text-cyan-300 border-r border-white/10"
              : "text-muted-foreground hover:text-foreground border-r border-white/10"
          }`}
        >
          <Zap className={`w-3.5 h-3.5 ${currentMode === "fast" ? "text-cyan-400" : ""}`} />
          Rápida
        </button>
        <button
          onClick={() => onChange("expert")}
          disabled={disabled}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold transition-all duration-200 disabled:opacity-40 ${
            currentMode === "expert"
              ? "bg-gradient-to-r from-violet-500/20 to-primary/20 text-violet-300"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Brain className={`w-3.5 h-3.5 ${currentMode === "expert" ? "text-violet-400" : ""}`} />
          Especialista
        </button>
      </div>
      <p className="text-[10px] text-muted-foreground mt-2 leading-relaxed">
        {currentMode === "fast"
          ? "Respostas rápidas e diretas ao ponto."
          : "Raciocínio profundo + busca na internet quando necessário."}
      </p>
    </div>
  );
}

export default function Home() {
  const {
    messages,
    isVoiceCallActive,
    isListening,
    isSpeaking,
    isThinking,
    isSearching,
    transcript,
    currentPersonality,
    currentMode,
    isOffline,
    handleSend,
    toggleVoiceCall,
    changePersonality,
    changeMode,
    clearChat
  } = useDianaChat();

  const [input, setInput] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isOffline || isThinking) return;
    handleSend(input);
    setInput("");
  };

  const sidebarContent = (
    <>
      <ModeToggle currentMode={currentMode} onChange={changeMode} disabled={isThinking || isVoiceCallActive} />
      <div className="flex-1 overflow-y-auto">
        <PersonalitySelector
          currentPersonality={currentPersonality}
          onSelect={changePersonality}
          disabled={isThinking || isVoiceCallActive || isOffline}
        />
      </div>
    </>
  );

  return (
    <div className="flex h-[100dvh] w-full bg-background overflow-hidden selection:bg-primary/30">

      {/* Sidebar Desktop */}
      <aside className="hidden md:flex w-72 flex-col border-r border-white/5 bg-card/30 backdrop-blur-xl">
        <div className="p-5 border-b border-white/5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-cyan-500 flex items-center justify-center shadow-lg shadow-primary/20 flex-shrink-0">
            <span className="text-white font-bold text-sm">D</span>
          </div>
          <div>
            <h1 className="font-bold tracking-widest bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">DIANA</h1>
            <p className="text-[10px] text-muted-foreground font-medium">Neural Assistant</p>
          </div>
        </div>
        {sidebarContent}
        <div className="p-4 border-t border-white/5">
          <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-destructive text-xs" onClick={clearChat}>
            <Trash2 className="w-3.5 h-3.5 mr-2" /> Limpar Conversa
          </Button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col relative min-w-0">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between px-4 py-3 border-b border-white/5 bg-background/80 backdrop-blur-md z-10">
          <div className="flex items-center gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="-ml-2 h-8 w-8">
                  <Menu className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-72 p-0 bg-background border-r-white/10">
                <div className="p-5 border-b border-white/5 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-cyan-500 flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-bold text-sm">D</span>
                  </div>
                  <h1 className="font-bold tracking-widest">DIANA</h1>
                </div>
                <div className="flex flex-col h-[calc(100%-61px)]">
                  {sidebarContent}
                  <div className="p-4 border-t border-white/5">
                    <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-destructive text-xs" onClick={clearChat}>
                      <Trash2 className="w-3.5 h-3.5 mr-2" /> Limpar Conversa
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
            <h1 className="font-bold tracking-widest text-sm bg-clip-text text-transparent bg-gradient-to-r from-primary to-cyan-400">DIANA</h1>
          </div>
          <div className="flex items-center gap-2">
            {isSearching && (
              <span className="text-[10px] text-violet-400 animate-pulse flex items-center gap-1">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-violet-400 animate-ping" />
                Pesquisando...
              </span>
            )}
            {isThinking && !isSearching && (
              <span className="text-[10px] text-primary animate-pulse">Pensando...</span>
            )}
          </div>
        </header>

        {/* Status banners */}
        {isOffline && (
          <div className="bg-destructive/10 border-b border-destructive/20 px-4 py-2 text-center text-xs text-destructive-foreground">
            DIANA offline — aguarde o modelo carregar
          </div>
        )}

        {/* Thinking/Searching status bar (desktop) */}
        {(isThinking || isSearching) && (
          <div className="hidden md:flex items-center justify-center gap-2 py-1.5 bg-primary/5 border-b border-white/5 text-xs">
            {isSearching ? (
              <>
                <Brain className="w-3 h-3 text-violet-400 animate-pulse" />
                <span className="text-violet-300 animate-pulse">Pesquisando na internet...</span>
              </>
            ) : (
              <>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary animate-ping" />
                <span className="text-primary animate-pulse">
                  {currentMode === "expert" ? "Analisando..." : "Pensando..."}
                </span>
              </>
            )}
          </div>
        )}

        {/* Chat */}
        <ChatArea messages={messages} isThinking={isThinking && !isSearching} isSearching={isSearching} currentMode={currentMode} />

        {/* Input */}
        <div className="p-3 md:p-4 bg-background/80 backdrop-blur-xl border-t border-white/5">
          <div className="max-w-3xl mx-auto">
            {/* Mode indicator pill */}
            <div className="flex items-center justify-between mb-2 px-1">
              <div className="flex items-center gap-1.5">
                {currentMode === "fast" ? (
                  <><Zap className="w-3 h-3 text-cyan-400" /><span className="text-[10px] text-cyan-400/70 font-medium">Modo Rápida</span></>
                ) : (
                  <><Brain className="w-3 h-3 text-violet-400" /><span className="text-[10px] text-violet-400/70 font-medium">Modo Especialista</span></>
                )}
              </div>
              {isSearching && (
                <span className="text-[10px] text-violet-400 animate-pulse flex items-center gap-1 md:hidden">
                  <Brain className="w-3 h-3" /> Pesquisando...
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                size="icon"
                variant={isVoiceCallActive ? "default" : "secondary"}
                className={`w-11 h-11 rounded-full flex-shrink-0 transition-all duration-300 ${isVoiceCallActive ? "bg-primary hover:bg-primary/90 shadow-lg shadow-primary/30" : "hover:bg-white/10"}`}
                onClick={toggleVoiceCall}
                disabled={isOffline}
              >
                <Phone className={`w-4 h-4 ${isVoiceCallActive ? "animate-pulse" : ""}`} />
              </Button>

              <form onSubmit={onSubmit} className="flex-1 flex items-center bg-muted/40 border border-white/10 rounded-3xl overflow-hidden focus-within:border-primary/40 focus-within:ring-1 focus-within:ring-primary/30 transition-all">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={currentMode === "expert" ? "Pergunte qualquer coisa — posso pesquisar na internet..." : "Mensagem para DIANA..."}
                  className="border-0 bg-transparent h-11 px-4 focus-visible:ring-0 text-sm"
                  disabled={isOffline || isThinking || isVoiceCallActive}
                />
                <Button
                  type="submit"
                  size="icon"
                  variant="ghost"
                  className="w-9 h-9 mr-1 rounded-full text-primary hover:bg-primary/20 transition-colors disabled:opacity-30"
                  disabled={!input.trim() || isOffline || isThinking || isVoiceCallActive}
                >
                  <Send className="w-3.5 h-3.5" />
                </Button>
              </form>
            </div>
          </div>
        </div>
      </main>

      <VoiceCallOverlay
        isActive={isVoiceCallActive}
        isListening={isListening}
        isSpeaking={isSpeaking}
        isThinking={isThinking}
        transcript={transcript}
        onEndCall={toggleVoiceCall}
      />
    </div>
  );
}
