import { Heart, BookOpen, Target, Briefcase } from "lucide-react";
import { Personality } from "@/hooks/use-diana-chat";
import { cn } from "@/lib/utils";

interface PersonalitySelectorProps {
  currentPersonality: Personality;
  onSelect: (p: Personality) => void;
  disabled?: boolean;
}

const personalities = [
  {
    id: "friend",
    name: "Amiga Empática",
    description: "Companhia amigável e acolhedora",
    icon: Heart,
    color: "text-rose-400",
    bg: "bg-rose-400/10",
    border: "border-rose-400/20"
  },
  {
    id: "teacher",
    name: "Professora Paciente",
    description: "Didática, explica conceitos passo a passo",
    icon: BookOpen,
    color: "text-blue-400",
    bg: "bg-blue-400/10",
    border: "border-blue-400/20"
  },
  {
    id: "coach",
    name: "Coach Motivacional",
    description: "Foco em metas, energia e produtividade",
    icon: Target,
    color: "text-orange-400",
    bg: "bg-orange-400/10",
    border: "border-orange-400/20"
  },
  {
    id: "assistant",
    name: "Assistente Profissional",
    description: "Objetiva, clara e focada em resultados",
    icon: Briefcase,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/20"
  }
] as const;

export function PersonalitySelector({ currentPersonality, onSelect, disabled }: PersonalitySelectorProps) {
  return (
    <div className="flex flex-col gap-2 p-4">
      <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Personalidade</h3>
      {personalities.map((p) => (
        <button
          key={p.id}
          disabled={disabled}
          onClick={() => onSelect(p.id as Personality)}
          className={cn(
            "flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-300",
            currentPersonality === p.id 
              ? cn(p.bg, p.border, "shadow-md") 
              : "border-transparent hover:bg-white/5",
            disabled && "opacity-50 cursor-not-allowed"
          )}
        >
          <div className={cn("p-2 rounded-full", currentPersonality === p.id ? "bg-background/50" : "bg-muted")}>
            <p.icon className={cn("w-4 h-4", p.color)} />
          </div>
          <div>
            <div className={cn("text-sm font-medium", currentPersonality === p.id ? "text-foreground" : "text-foreground/80")}>
              {p.name}
            </div>
            <div className="text-xs text-muted-foreground line-clamp-1">
              {p.description}
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}
