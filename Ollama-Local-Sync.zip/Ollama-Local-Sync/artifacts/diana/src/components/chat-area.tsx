import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Globe, Brain } from "lucide-react";
import { Message, type Mode } from "@/hooks/use-diana-chat";
import { DianaAvatar } from "./diana-avatar";
import { cn } from "@/lib/utils";

interface ChatAreaProps {
  messages: Message[];
  isThinking: boolean;
  isSearching?: boolean;
  currentMode?: Mode;
}

export function ChatArea({ messages, isThinking, isSearching, currentMode }: ChatAreaProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isThinking, isSearching]);

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5 scroll-smooth">
      <AnimatePresence initial={false}>
        {messages.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center h-full text-center space-y-4 py-16"
          >
            <DianaAvatar isThinking={false} isSpeaking={false} isListening={false} size="lg" className="mb-4" />
            <h2 className="text-2xl font-light text-foreground/80">Olá, eu sou a DIANA.</h2>
            <p className="text-muted-foreground max-w-md text-sm">
              Sua assistente neural. Como posso ajudar você hoje?
            </p>
            {currentMode === "expert" && (
              <div className="flex items-center gap-1.5 text-[11px] text-violet-400/70 bg-violet-500/10 border border-violet-500/20 rounded-full px-3 py-1.5 mt-2">
                <Brain className="w-3 h-3" />
                Modo Especialista ativo — posso buscar na internet
              </div>
            )}
          </motion.div>
        )}

        {messages.map((msg) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 10, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={cn(
              "flex max-w-[88%] md:max-w-[78%]",
              msg.role === "user" ? "ml-auto justify-end" : "mr-auto justify-start"
            )}
          >
            {msg.role === "diana" && (
              <div className="mr-2.5 mt-1 flex-shrink-0">
                <DianaAvatar isThinking={false} isSpeaking={false} isListening={false} size="sm" />
              </div>
            )}

            <div className="flex flex-col gap-1">
              {/* Search badge */}
              {msg.role === "diana" && msg.searchUsed && (
                <div className="flex items-center gap-1 text-[10px] text-violet-400/80 mb-0.5">
                  <Globe className="w-2.5 h-2.5" />
                  <span>Pesquisado: {msg.searchQuery}</span>
                </div>
              )}

              <div className={cn(
                "p-3.5 md:p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap break-words",
                msg.role === "user"
                  ? "bg-primary text-primary-foreground rounded-tr-sm"
                  : "bg-muted text-foreground rounded-tl-sm border border-white/5"
              )}>
                {msg.content}
              </div>

              {/* Timestamp */}
              <span className={cn(
                "text-[10px] text-muted-foreground/40 px-1",
                msg.role === "user" ? "text-right" : "text-left"
              )}>
                {msg.timestamp.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
              </span>
            </div>
          </motion.div>
        ))}

        {/* Searching indicator */}
        {isSearching && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex max-w-[88%] mr-auto justify-start"
          >
            <div className="mr-2.5 mt-1 flex-shrink-0">
              <DianaAvatar isThinking={true} isSpeaking={false} isListening={false} size="sm" />
            </div>
            <div className="p-3.5 rounded-2xl bg-violet-500/10 text-violet-300 rounded-tl-sm border border-violet-500/20 flex items-center gap-2 text-xs">
              <Globe className="w-3.5 h-3.5 animate-pulse flex-shrink-0" />
              <span className="animate-pulse">Pesquisando na internet...</span>
              <span className="flex gap-0.5">
                <span className="w-1 h-1 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-1 h-1 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-1 h-1 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: "300ms" }} />
              </span>
            </div>
          </motion.div>
        )}

        {/* Thinking indicator */}
        {isThinking && !isSearching && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex max-w-[88%] mr-auto justify-start"
          >
            <div className="mr-2.5 mt-1 flex-shrink-0">
              <DianaAvatar isThinking={true} isSpeaking={false} isListening={false} size="sm" />
            </div>
            <div className="p-3.5 rounded-2xl bg-muted text-foreground rounded-tl-sm border border-white/5 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "0ms" }} />
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "150ms" }} />
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
