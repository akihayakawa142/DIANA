import { motion, AnimatePresence } from "framer-motion";
import { PhoneOff, Mic } from "lucide-react";
import { DianaAvatar } from "./diana-avatar";
import { Button } from "@/components/ui/button";

interface VoiceCallOverlayProps {
  isActive: boolean;
  isListening: boolean;
  isSpeaking: boolean;
  isThinking: boolean;
  transcript: string;
  onEndCall: () => void;
}

export function VoiceCallOverlay({ isActive, isListening, isSpeaking, isThinking, transcript, onEndCall }: VoiceCallOverlayProps) {
  if (!isActive) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="fixed inset-0 z-50 bg-background/95 backdrop-blur-xl flex flex-col items-center justify-between p-8"
      >
        <div className="w-full flex justify-between items-start">
          <div className="text-xl font-light tracking-widest bg-clip-text text-transparent bg-gradient-to-r from-primary to-cyan-400">
            DIANA
          </div>
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-muted-foreground">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            Chamada Ativa
          </div>
        </div>

        <div className="flex flex-col items-center justify-center flex-1 w-full max-w-2xl relative">
          <DianaAvatar 
            isThinking={isThinking} 
            isSpeaking={isSpeaking} 
            isListening={isListening} 
            size="xl" 
            className="mb-12 shadow-2xl shadow-primary/20 rounded-full"
          />
          
          <div className="h-24 w-full flex items-center justify-center">
            <AnimatePresence mode="wait">
              {transcript ? (
                <motion.p 
                  key="transcript"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-lg md:text-2xl text-center font-light text-foreground/90 max-w-xl line-clamp-3"
                >
                  "{transcript}"
                </motion.p>
              ) : isThinking ? (
                <motion.p 
                  key="thinking"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-primary/70 font-light tracking-wider"
                >
                  Pensando...
                </motion.p>
              ) : isSpeaking ? (
                <motion.p 
                  key="speaking"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-cyan-400/70 font-light tracking-wider"
                >
                  Falando...
                </motion.p>
              ) : (
                <motion.p 
                  key="listening"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-muted-foreground font-light tracking-wider flex items-center gap-2"
                >
                  <Mic className="w-4 h-4" /> Ouvindo...
                </motion.p>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="pb-8">
          <Button 
            variant="destructive" 
            size="icon" 
            className="w-16 h-16 rounded-full shadow-lg shadow-destructive/30 hover:scale-105 transition-transform"
            onClick={onEndCall}
          >
            <PhoneOff className="w-6 h-6" />
          </Button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
