import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface DianaAvatarProps {
  isThinking: boolean;
  isSpeaking: boolean;
  isListening: boolean;
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
}

export function DianaAvatar({ isThinking, isSpeaking, isListening, className, size = "md" }: DianaAvatarProps) {
  
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-24 h-24",
    xl: "w-48 h-48"
  };

  let orbStateClass = "orb-pulse";
  if (isThinking) orbStateClass = "orb-thinking";
  if (isSpeaking) orbStateClass = "orb-speaking";
  if (isListening && !isThinking && !isSpeaking) orbStateClass = "orb-pulse glow-secondary";

  return (
    <div className={cn("relative flex items-center justify-center", sizeClasses[size], className)}>
      <motion.div 
        className={cn(
          "absolute inset-0 rounded-full bg-gradient-to-br from-primary to-secondary opacity-80",
          orbStateClass
        )}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      />
      
      {/* Inner core */}
      <div className="absolute inset-[15%] rounded-full bg-background/50 backdrop-blur-sm" />
      <div className="absolute inset-[25%] rounded-full bg-gradient-to-tr from-cyan-400 to-violet-500 opacity-90 mix-blend-screen" />
    </div>
  );
}
