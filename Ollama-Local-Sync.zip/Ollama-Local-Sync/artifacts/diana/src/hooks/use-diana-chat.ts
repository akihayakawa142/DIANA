import { useState, useEffect, useRef, useCallback } from "react";
import { 
  useSendMessage, 
  useSetPersonality, 
  useGetDianaStatus, 
  useResetConversation,
  getGetDianaStatusQueryKey
} from "@workspace/api-client-react";

export type Message = {
  id: string;
  role: "user" | "diana";
  content: string;
  timestamp: Date;
  searchUsed?: boolean;
  searchQuery?: string;
};

export type Personality = "friend" | "teacher" | "coach" | "assistant";
export type Mode = "fast" | "expert";

const getOrCreateSessionId = () => {
  let sessionId = sessionStorage.getItem("diana_session_id");
  if (!sessionId) {
    sessionId = crypto.randomUUID();
    sessionStorage.setItem("diana_session_id", sessionId);
  }
  return sessionId;
};

const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;

export const useDianaChat = () => {
  const [sessionId] = useState(getOrCreateSessionId);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentPersonality, setCurrentPersonality] = useState<Personality>("friend");
  const [currentMode, setCurrentMode] = useState<Mode>("fast");
  
  const [isVoiceCallActive, setIsVoiceCallActive] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [transcript, setTranscript] = useState("");

  const { data: status, isError: isStatusError } = useGetDianaStatus({ 
    query: { 
      queryKey: getGetDianaStatusQueryKey(),
      refetchInterval: 5000 
    } 
  });

  const sendMessage = useSendMessage();
  const setPersonality = useSetPersonality();
  const resetConversation = useResetConversation();

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis>(window.speechSynthesis);
  const voicesRef = useRef<SpeechSynthesisVoice[]>([]);
  const isVoiceCallActiveRef = useRef(false);

  useEffect(() => {
    isVoiceCallActiveRef.current = isVoiceCallActive;
  }, [isVoiceCallActive]);

  useEffect(() => {
    const loadVoices = () => {
      voicesRef.current = synthRef.current.getVoices();
    };
    loadVoices();
    if (synthRef.current.onvoiceschanged !== undefined) {
      synthRef.current.onvoiceschanged = loadVoices;
    }
  }, []);

  const getBestVoice = () => {
    const voices = voicesRef.current;
    if (!voices.length) return null;
    const ptBrFemale = voices.find(v => v.lang.includes('pt-BR') && (v.name.includes('Feminine') || v.name.includes('Google') || v.name.includes('Maria')));
    if (ptBrFemale) return ptBrFemale;
    const ptBr = voices.find(v => v.lang.includes('pt-BR'));
    if (ptBr) return ptBr;
    const ptFemale = voices.find(v => v.lang.includes('pt') && v.name.includes('Female'));
    if (ptFemale) return ptFemale;
    return voices[0];
  };

  const speakText = useCallback((text: string, onEnd?: () => void) => {
    if (!synthRef.current) return;
    synthRef.current.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voice = getBestVoice();
    if (voice) utterance.voice = voice;
    utterance.lang = "pt-BR";
    utterance.rate = currentMode === "fast" ? 1.1 : 1.0;
    utterance.pitch = 1.1;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => { setIsSpeaking(false); if (onEnd) onEnd(); };
    utterance.onerror = () => { setIsSpeaking(false); if (onEnd) onEnd(); };
    synthRef.current.speak(utterance);
  }, [currentMode]);

  const startListeningFn = useCallback(() => {
    if (!SpeechRecognition || !isVoiceCallActiveRef.current) return;
    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'pt-BR';
      recognition.continuous = false;
      recognition.interimResults = true;
      recognitionRef.current = recognition;

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        let t = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          t += event.results[i][0].transcript;
        }
        setTranscript(t);
      };
      recognition.onend = () => {
        setIsListening(false);
        const currentTranscript = recognitionRef.current?._lastTranscript || "";
        if (currentTranscript.trim() && isVoiceCallActiveRef.current) {
          handleSendFn(currentTranscript.trim());
          setTranscript("");
        } else if (isVoiceCallActiveRef.current) {
          setTimeout(() => {
            if (isVoiceCallActiveRef.current) startListeningFn();
          }, 500);
        }
      };
      recognition.onerror = () => setIsListening(false);

      // Track transcript for onend handler
      recognition.onresult = (event: any) => {
        let t = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          t += event.results[i][0].transcript;
        }
        setTranscript(t);
        if (recognitionRef.current) recognitionRef.current._lastTranscript = t;
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  }, []);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch {}
    }
    setIsListening(false);
  }, []);

  const toggleVoiceCall = useCallback(() => {
    setIsVoiceCallActive(prev => !prev);
  }, []);

  const handleSendFn = useCallback(async (content: string, modeOverride?: Mode) => {
    if (!content.trim() || isThinking) return;

    const effectiveMode = modeOverride || currentMode;
    const userMsg: Message = { id: crypto.randomUUID(), role: "user", content, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setIsThinking(true);
    if (effectiveMode === "expert") setIsSearching(false);
    stopListening();

    // Show searching indicator with slight delay for expert mode (server decides)
    let searchTimer: ReturnType<typeof setTimeout> | null = null;
    if (effectiveMode === "expert") {
      searchTimer = setTimeout(() => setIsSearching(true), 1200);
    }

    try {
      const res = await sendMessage.mutateAsync({
        data: {
          message: content,
          sessionId,
          personality: currentPersonality,
          mode: effectiveMode,
        }
      });

      if (searchTimer) clearTimeout(searchTimer);
      setIsSearching(false);

      const dianaMsg: Message = {
        id: crypto.randomUUID(),
        role: "diana",
        content: res.response,
        timestamp: new Date(),
        searchUsed: res.searchUsed,
        searchQuery: res.searchQuery,
      };
      setMessages(prev => [...prev, dianaMsg]);
      
      if (isVoiceCallActiveRef.current) {
        speakText(res.response, () => {
          if (isVoiceCallActiveRef.current) startListeningFn();
        });
      }
    } catch {
      if (searchTimer) clearTimeout(searchTimer);
      setIsSearching(false);
      const errorMsg: Message = { id: crypto.randomUUID(), role: "diana", content: "Desculpe, ocorreu um erro de conexão. Pode repetir?", timestamp: new Date() };
      setMessages(prev => [...prev, errorMsg]);
      if (isVoiceCallActiveRef.current) {
        speakText(errorMsg.content, () => {
          if (isVoiceCallActiveRef.current) startListeningFn();
        });
      }
    } finally {
      setIsThinking(false);
    }
  }, [isThinking, currentMode, sessionId, currentPersonality, sendMessage, speakText, stopListening, startListeningFn]);

  const handleSend = useCallback((content: string) => {
    return handleSendFn(content);
  }, [handleSendFn]);

  useEffect(() => {
    if (isVoiceCallActive) {
      if (!isSpeaking && !isThinking) startListeningFn();
    } else {
      stopListening();
      synthRef.current?.cancel();
      setIsSpeaking(false);
    }
  }, [isVoiceCallActive]);

  const changePersonality = async (personality: Personality) => {
    setCurrentPersonality(personality);
    try {
      await setPersonality.mutateAsync({ data: { personality, sessionId } });
      const names: Record<string, string> = {
        friend: "Amiga Empática", teacher: "Professora Paciente",
        coach: "Coach Motivacional", assistant: "Assistente Profissional",
      };
      const changeMsg: Message = { id: crypto.randomUUID(), role: "diana", content: `Personalidade alterada para ${names[personality]}. Como posso ajudar?`, timestamp: new Date() };
      setMessages(prev => [...prev, changeMsg]);
      if (isVoiceCallActiveRef.current) speakText(changeMsg.content);
    } catch {}
  };

  const changeMode = (mode: Mode) => {
    setCurrentMode(mode);
  };

  const clearChat = async () => {
    try {
      await resetConversation.mutateAsync({ data: { sessionId } });
      setMessages([]);
    } catch {}
  };

  return {
    messages,
    isVoiceCallActive,
    isListening,
    isSpeaking,
    isThinking,
    isSearching,
    transcript,
    currentPersonality,
    currentMode,
    status,
    isOffline: !status?.ollamaRunning || isStatusError,
    handleSend,
    toggleVoiceCall,
    changePersonality,
    changeMode,
    clearChat
  };
};
