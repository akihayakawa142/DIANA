#!/usr/bin/env bash
set -e

echo "=== DIANA API Server Startup ==="

# Start Ollama server if not already running
if ! curl -sf http://localhost:11434/api/tags >/dev/null 2>&1; then
  echo "Starting Ollama server..."
  OLLAMA_HOST=127.0.0.1 OLLAMA_ORIGINS="*" ollama serve &
  
  # Wait for Ollama to be ready
  for i in $(seq 1 30); do
    if curl -sf http://localhost:11434/api/tags >/dev/null 2>&1; then
      echo "Ollama ready!"
      break
    fi
    sleep 1
  done
else
  echo "Ollama already running."
fi

# Pull model in background if not available
MODEL="${OLLAMA_MODEL:-llama3.2}"
if ! ollama list 2>/dev/null | grep -q "$MODEL"; then
  echo "Pulling model $MODEL in background..."
  ollama pull "$MODEL" &
fi

echo "Starting API server..."
export NODE_ENV=development
node /home/runner/workspace/artifacts/api-server/dist/index.mjs
