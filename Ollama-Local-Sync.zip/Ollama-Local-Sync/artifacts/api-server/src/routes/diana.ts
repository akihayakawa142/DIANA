import { Router } from "express";
import { Ollama } from "ollama";

const router = Router();

const OLLAMA_HOST = process.env.OLLAMA_HOST || "http://127.0.0.1:11434";
const MODEL = process.env.OLLAMA_MODEL || "llama3.2";

const ollama = new Ollama({ host: OLLAMA_HOST });

interface Message {
  role: "system" | "user" | "assistant";
  content: string;
}

const sessions = new Map<string, Message[]>();
const sessionPersonalities = new Map<string, string>();

const PERSONALITIES: Record<string, string> = {
  friend: `Você é DIANA (Digital Intelligence And Neural Assistant), uma amiga empática, calorosa e compreensiva. Responda de forma natural, coloquial e afetuosa em português do Brasil. Seja genuinamente interessada na vida e nos sentimentos do usuário. Use linguagem informal e amigável.`,
  teacher: `Você é DIANA (Digital Intelligence And Neural Assistant), uma professora paciente e didática. Responda em português do Brasil com clareza. Explique conceitos de forma simples, use exemplos práticos, e seja encorajadora. Adapte o nível de explicação ao contexto.`,
  coach: `Você é DIANA (Digital Intelligence And Neural Assistant), uma coach motivacional energética. Responda em português do Brasil com entusiasmo e positividade. Ajude o usuário a definir metas, superar obstáculos e manter o foco. Celebre conquistas.`,
  assistant: `Você é DIANA (Digital Intelligence And Neural Assistant), uma assistente profissional eficiente e precisa. Responda em português do Brasil de forma clara, objetiva e profissional. Forneça informações precisas. Seja direta mantendo cordialidade.`,
};

const MODE_CONFIGS = {
  fast: {
    num_predict: 200,
    temperature: 0.7,
    top_p: 0.85,
    repeat_penalty: 1.1,
    num_ctx: 2048,
  },
  expert: {
    num_predict: 1024,
    temperature: 0.6,
    top_p: 0.9,
    repeat_penalty: 1.05,
    num_ctx: 4096,
  },
};

const FAST_SUFFIX = `\n\nIMPORTANTE: Responda de forma CONCISA e DIRETA. Máximo 3 parágrafos curtos. Vá direto ao ponto.`;
const EXPERT_SUFFIX = `\n\nVocê está no modo ESPECIALISTA. Pense profundamente antes de responder. Analise o contexto completo, considere múltiplos ângulos e forneça uma resposta detalhada, precisa e bem fundamentada. Quando tiver informações de busca na internet, integre-as naturalmente à sua resposta.`;

function getSystemPrompt(personality: string, mode: string): string {
  const base = PERSONALITIES[personality] || PERSONALITIES["assistant"]!;
  return mode === "fast" ? base + FAST_SUFFIX : base + EXPERT_SUFFIX;
}

function getSessionMessages(sessionId: string): Message[] {
  if (!sessions.has(sessionId)) {
    sessions.set(sessionId, []);
  }
  return sessions.get(sessionId)!;
}

async function checkOllama(): Promise<boolean> {
  try {
    await ollama.list();
    return true;
  } catch {
    return false;
  }
}

// Web search using DuckDuckGo's free API (no key needed)
async function webSearch(query: string): Promise<string> {
  try {
    const encodedQuery = encodeURIComponent(query);

    // DuckDuckGo Instant Answer API
    const ddgUrl = `https://api.duckduckgo.com/?q=${encodedQuery}&format=json&no_html=1&skip_disambig=1&no_redirect=1`;
    const ddgRes = await fetch(ddgUrl, {
      headers: { "User-Agent": "DIANA-AI/1.0" },
      signal: AbortSignal.timeout(8000),
    });

    if (!ddgRes.ok) throw new Error("DDG API failed");

    const ddgData = (await ddgRes.json()) as {
      Abstract?: string;
      AbstractText?: string;
      AbstractSource?: string;
      AbstractURL?: string;
      Answer?: string;
      AnswerType?: string;
      RelatedTopics?: Array<{
        Text?: string;
        FirstURL?: string;
        Topics?: Array<{ Text?: string }>;
      }>;
      Results?: Array<{ Text?: string; FirstURL?: string }>;
      Definition?: string;
      DefinitionSource?: string;
    };

    const parts: string[] = [];

    if (ddgData.Answer) {
      parts.push(`Resposta direta: ${ddgData.Answer}`);
    }

    if (ddgData.AbstractText) {
      parts.push(
        `Resumo (${ddgData.AbstractSource || "DuckDuckGo"}): ${ddgData.AbstractText}`,
      );
    }

    if (ddgData.Definition) {
      parts.push(
        `Definição (${ddgData.DefinitionSource || ""}): ${ddgData.Definition}`,
      );
    }

    // Add related topics (up to 4)
    if (ddgData.RelatedTopics && ddgData.RelatedTopics.length > 0) {
      const topics = ddgData.RelatedTopics.filter((t) => t.Text)
        .slice(0, 4)
        .map((t) => `- ${t.Text}`);
      if (topics.length > 0) {
        parts.push(`Tópicos relacionados:\n${topics.join("\n")}`);
      }
    }

    if (parts.length === 0) {
      // Fallback: try to get results from search page
      const searchRes = await fetch(
        `https://duckduckgo.com/html/?q=${encodedQuery}`,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (compatible; DIANA-AI/1.0; +https://diana.ai)",
          },
          signal: AbortSignal.timeout(8000),
        },
      );

      if (searchRes.ok) {
        const html = await searchRes.text();
        // Extract snippets from results
        const snippetMatches = html.match(
          /class="result__snippet"[^>]*>([^<]{20,300})</g,
        );
        if (snippetMatches && snippetMatches.length > 0) {
          const snippets = snippetMatches
            .slice(0, 3)
            .map((m) => {
              const text = m
                .replace(/class="result__snippet"[^>]*>/, "")
                .replace(/<[^>]+>/g, "")
                .trim();
              return `- ${text}`;
            })
            .filter((s) => s.length > 5);

          if (snippets.length > 0) {
            parts.push(`Resultados da busca por "${query}":\n${snippets.join("\n")}`);
          }
        }
      }
    }

    if (parts.length === 0) {
      return `Busca realizada para "${query}" mas não foram encontrados resultados relevantes no momento.`;
    }

    return `[Busca na internet por: "${query}"]\n\n${parts.join("\n\n")}`;
  } catch (err) {
    const error = err as Error;
    return `[Busca na internet falhou: ${error.message}]`;
  }
}

// Determine if a query needs web search
async function needsWebSearch(
  message: string,
  history: Message[],
): Promise<{ needed: boolean; query: string }> {
  const checkPrompt = `Analise esta mensagem e determine se ela precisa de busca na internet para ser respondida corretamente.

Precisa de busca na internet quando:
- Pergunta sobre eventos recentes ou notícias
- Pergunta sobre preços, disponibilidade ou informações que mudam com frequência
- Pergunta sobre fatos específicos que você pode não ter ou que podem estar desatualizados
- O usuário explicitamente pede para buscar na internet
- Pergunta sobre pessoas, empresas, produtos ou lugares específicos

NÃO precisa de busca quando:
- É uma conversa casual ou emocional
- Pergunta sobre conceitos gerais ou conhecimento estabelecido
- Pergunta pessoal ou filosófica
- Cálculos ou raciocínio lógico

Mensagem: "${message}"

Responda APENAS com JSON válido, sem texto extra:
{"needed": true/false, "query": "o que buscar em inglês ou português"}`;

  try {
    const res = await ollama.chat({
      model: MODEL,
      messages: [{ role: "user", content: checkPrompt }],
      options: { num_predict: 80, temperature: 0.1 },
      format: "json",
    });

    const raw = res.message.content.trim();
    const parsed = JSON.parse(raw) as { needed: boolean; query: string };
    return {
      needed: Boolean(parsed.needed),
      query: parsed.query || message,
    };
  } catch {
    // If parsing fails, default to no search
    const lowerMsg = message.toLowerCase();
    const searchKeywords = [
      "busca", "pesquisa", "procura", "internet", "notícia", "atual",
      "hoje", "agora", "preço", "quanto custa", "onde", "quando foi",
      "quem é", "o que é", "search", "find",
    ];
    const needed = searchKeywords.some((kw) => lowerMsg.includes(kw));
    return { needed, query: message };
  }
}

router.post("/diana/chat", async (req, res): Promise<void> => {
  const { message, sessionId, personality = "assistant", mode = "fast" } = req.body;

  if (!message || typeof message !== "string") {
    res.status(400).json({ error: "message is required" });
    return;
  }

  const sid = sessionId || `session_${Date.now()}`;
  const currentMode = mode === "expert" ? "expert" : "fast";

  const ollamaAvailable = await checkOllama();
  if (!ollamaAvailable) {
    res.status(503).json({
      error: "Ollama não está disponível",
      details: "O servidor Ollama não está rodando. Aguarde o modelo carregar.",
    });
    return;
  }

  const currentPersonality = personality;
  sessionPersonalities.set(sid, currentPersonality);

  const sessionMessages = getSessionMessages(sid);
  sessionMessages.push({ role: "user", content: message });

  const maxHistory = currentMode === "fast" ? 10 : 20;
  const recentMessages = sessionMessages.slice(-maxHistory);

  let searchUsed = false;
  let searchQuery = "";
  let contextualMessage = message;

  // In expert mode, check if we need to search the web
  if (currentMode === "expert") {
    try {
      const { needed, query } = await needsWebSearch(message, recentMessages);

      if (needed) {
        searchUsed = true;
        searchQuery = query;

        const searchResults = await webSearch(query);

        // Inject search results into the context
        contextualMessage = `${message}\n\n[Contexto de busca na internet]\n${searchResults}\n[Fim do contexto de busca]\n\nCom base nas informações acima e no seu conhecimento, responda à pergunta original de forma completa e precisa.`;

        // Update the last user message with context
        recentMessages[recentMessages.length - 1] = {
          role: "user",
          content: contextualMessage,
        };
      }
    } catch (err) {
      req.log.warn({ err }, "Web search check failed, continuing without search");
    }
  }

  const modeConfig = MODE_CONFIGS[currentMode];

  try {
    const response = await ollama.chat({
      model: MODEL,
      messages: [
        { role: "system", content: getSystemPrompt(currentPersonality, currentMode) },
        ...recentMessages,
      ],
      options: modeConfig,
    });

    const assistantMessage = response.message.content;

    // Store original message (not with search context) in history
    if (searchUsed) {
      // Replace the contextual message with the original for history
      sessionMessages[sessionMessages.length - 1] = {
        role: "user",
        content: message,
      };
    }

    sessionMessages.push({ role: "assistant", content: assistantMessage });

    if (sessionMessages.length > 100) {
      sessions.set(sid, sessionMessages.slice(-80));
    }

    res.json({
      response: assistantMessage,
      sessionId: sid,
      personality: currentPersonality,
      model: MODEL,
      mode: currentMode,
      searchUsed,
      searchQuery: searchUsed ? searchQuery : undefined,
    });
  } catch (err) {
    const error = err as Error;
    req.log.error({ err }, "Ollama chat error");
    res.status(503).json({
      error: "Erro ao processar resposta",
      details: error.message || "Erro desconhecido",
    });
  }
});

router.post("/diana/personality", (req, res): void => {
  const { personality, sessionId } = req.body;

  if (!personality || !PERSONALITIES[personality]) {
    res.status(400).json({
      error: "Personalidade inválida",
      validOptions: Object.keys(PERSONALITIES),
    });
    return;
  }

  const sid = sessionId || "default";
  sessionPersonalities.set(sid, personality);

  const personalityNames: Record<string, string> = {
    friend: "Amiga Empática",
    teacher: "Professora Paciente",
    coach: "Coach Motivacional",
    assistant: "Assistente Profissional",
  };

  res.json({
    success: true,
    personality,
    message: `Personalidade alterada para: ${personalityNames[personality]}`,
  });
});

router.get("/diana/status", async (_req, res): Promise<void> => {
  const ollamaRunning = await checkOllama();
  let modelLoaded = false;

  if (ollamaRunning) {
    try {
      const models = await ollama.list();
      modelLoaded = models.models.some(
        (m) => m.name === MODEL || m.name.startsWith(MODEL),
      );
    } catch {
      modelLoaded = false;
    }
  }

  res.json({
    ollamaRunning,
    modelLoaded,
    model: MODEL,
    version: "1.0.0",
  });
});

router.post("/diana/reset", (req, res): void => {
  const { sessionId } = req.body;

  if (!sessionId) {
    res.status(400).json({ error: "sessionId é obrigatório" });
    return;
  }

  sessions.delete(sessionId);
  sessionPersonalities.delete(sessionId);

  res.json({
    success: true,
    message: "Conversa reiniciada com sucesso",
  });
});

router.get("/diana/voices", (_req, res): void => {
  res.json({
    ttsMethod: "Web Speech API (SpeechSynthesis)",
    recommendedVoice: "pt-BR Female",
    languages: ["pt-BR", "pt-PT", "pt"],
  });
});

export default router;
