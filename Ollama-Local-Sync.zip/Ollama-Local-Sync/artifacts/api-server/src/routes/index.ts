import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dianaRouter from "./diana";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dianaRouter);

export default router;
